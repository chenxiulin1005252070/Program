#include "public_ui.h"
#include "public.h"
#include "commonlist.h"
#include "stuInfo.h"
#include <string.h>
#include <stdlib.h>
#include "fileope.h"
#include "function.h"

int main()
{
	char pszTime[20] = "";
	int nRtnChoose = 0;
	FILE* pFile = NULL ;

	STCOMLIST* pstStuList = InitFunc("stuInfo.txt", &pFile, nRtnAddStu); /**< ��ʼ������ */
	STCOMLIST* pstStuListFalse = InitFunc("stuInfo.txt", &pFile, NULL); /**< ��ʼ������ */
	
	while(1)
	{	
		ShowLoginUi();
		GetCurTime(pszTime);
		PrintTextPos(2,4,pszTime);
		nRtnChoose = nChooseFuc(1,0,6,1,"��",0,0);
		switch(nRtnChoose)
		{
		case 0:
			{
				
				ShowDisplayFuc(pstStuList, pstStuListFalse, pFile );
				break;
			}
		case 1:
				ShowAddFuc(pstStuList, pstStuListFalse, pFile);
				break;
		case 2:
				ShowSrchFuc(pstStuList, pstStuListFalse, pFile);
				break;
		case 3:
				ShowModFuc(pstStuList, pstStuListFalse, pFile);
				break;
		case 4:
				ShowDelFuc(pstStuList, pstStuListFalse, pFile);
				break;
		case 5:	
			
		case APP_BACK:
			{
				PrintTextPos(1,20,"");
				return APP_SUCC;
			}
			
		default :
			break;
			
		}

	}


	return APP_SUCC;
}