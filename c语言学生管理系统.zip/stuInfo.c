#include "stuInfo.h"
#include <stdio.h>
#include <string.h>
#include "public.h"
void PrintStuInfo(void *pData)
{
	STINFO *pNode =(STINFO *) pData;
	printf("%-10s%-10s",pNode->szNo, pNode->szName);
}
int FindStu(void *pData,char *psValue)
{
	STINFO *pNode = (STINFO *)pData;
	if (strcmp(pNode->szNo,psValue) == 0)
	{
		if(pNode->nRmvFlag !=1)
			return 1;
	}
	return 0;

}

int nRmvStu (void* pData,char* psValue)
{
	STINFO *pNode = (STINFO *)pData;
    if (strcmp(pNode->szNo,psValue) == 0 && pNode->nRmvFlag != 1) 
	{
		pNode->nRmvFlag = 1;
		return APP_SUCC;
	}
	return APP_FAIL;
}

int nRtnAddStu(void* pData)
{
	STINFO *pNode = (STINFO *)pData;
	return pNode->nRmvFlag;
}
int FindStuByName (void* pData,char* psValue)
{
	STINFO *pNode = (STINFO *)pData;
	return strcmp(pNode->szName,psValue)? 0:1;
}
