#include "public_ui.h"
#include <windows.h>
#include "public.h"
void ShowLoginUi()
{
	system("cls");
	printf ("|   ѧ����Ϣ����ϵͳ   |\n");
	printf ("|   1.�� ʾ   4.�� ��  |\n");
	printf ("|   2.�� ��   5.ɾ ��  |\n");
	printf ("|   3.�� ѯ   6.�� ��  |\n");
	printf ("|                      |\n");

}
/**< 
char szName[MAX_LEN+1];
	int nAge;
	float fGrade;
	float fTuition;
*/
void ShowDisplayUi()
{
	system("cls");
	printf ("|       ѧ����Ϣ       |\n");
	printf ("|                      |\n");
	printf ("|                      |\n");
	printf ("|                      |\n");
	printf ("|   ���� ��ҳ          |\n");
}


void ShowDelUi(int nX, int nY)
{
	SetCurPos(nX, nY);
	printf ("----------------\n");
	SetCurPos(nX, nY + 1);
	printf ("|    ɾ����    |\n");
	SetCurPos(nX, nY + 2);
	printf ("|    ɾ ��     |\n");
	SetCurPos(nX, nY + 3);
	printf ("----------------\n");
}
void ShowDelUiOne(int nX, int nY)
{
	SetCurPos(nX, nY);
	printf ("---------------\n");
	SetCurPos(nX, nY + 1);
	printf ("|   �Ƿ�ɾ��  |\n");
	SetCurPos(nX, nY + 2);
	printf ("|  ��      �� |\n");
	SetCurPos(nX, nY + 3);
	printf ("---------------\n");
}

void ShowAddUi()
{
	system("cls");
	printf ("|    ѧ����Ϣ����      |\n");
	printf ("|  ѧ��                |\n");
	printf ("|   1.�� ��   4.ѧ ��  |\n");
	printf ("|   2.�� ��   5.�� ��  |\n");
	printf ("|   3.�� ��   6.�� ��  |\n");

}
void ShowSrchUi()
{
	system("cls");
	printf ("|   ѧ����Ϣ��ѯ       |\n");
	printf ("|                      |\n");
	printf ("|  ѧ��                |\n");
	printf ("|                      |\n");
	printf ("|  enterȷ��   esc���� |\n");
}



void ShowModFucUi()
{

	system("cls");
	printf ("-------------------------------------------------------\n");
	printf ("|                      ��ǰѧ����Ϣ                   |\n");
	printf ("|                                                     |\n");
	printf ("|         ѧ��                                        |\n");
	printf ("|                                                     |\n");
	printf ("|         ����                                        |\n");
	printf ("|                                                     |\n");
	printf ("|         ����                                        |\n");
	printf ("|                                                     |\n");
	printf ("|         ����                                        |\n");
	printf ("|                                                     |\n");
	printf ("|         ѧ��                                        |\n");
	printf ("|                                                     |\n");
	printf ("|                                                     |\n");
	printf ("|                  ����            ȡ��               |\n");
	printf ("|                                                     |\n");
	printf ("|                                                     |\n");
	printf ("|                                                     |\n");
	printf ("-------------------------------------------------------\n");
}
void ShowModSubUi(int nX, int nY)
{
	SetCurPos(nX, nY);
	printf ("-------------------\n");
	SetCurPos(nX, nY + 1);
	printf ("|   ����ѧ��      |\n");
	SetCurPos(nX, nY + 2);
	printf ("| ѧ��            |\n");
	SetCurPos(nX, nY + 3);
	printf ("|enterȷ�� esc����|\n");
	SetCurPos(nX, nY + 4);
	printf ("-------------------\n");
}

void ShowNameUi()
{
	system("cls");
	printf ("|   ѧ����Ϣ����       |\n");
	printf ("|                      |\n");
	printf ("|  ����                |\n");
	printf ("|                      |\n");
	printf ("|  enterȷ��   esc���� |\n");
}
void ShowAgeUi()
{
	system("cls");
	printf ("|   ѧ����Ϣ����       |\n");
	printf ("|                      |\n");
	printf ("|  ����                |\n");
	printf ("|                      |\n");
	printf ("|  enterȷ��   esc���� |\n");
}
void ShowGradeUi()
{
	system("cls");
	printf ("|   ѧ����Ϣ����       |\n");
	printf ("|                      |\n");
	printf ("|  ����                |\n");
	printf ("|                      |\n");
	printf ("|  enterȷ��   esc���� |\n");
}
void ShowTuiTionUi()
{
	system("cls");
	printf ("|   ѧ����Ϣ����       |\n");
	printf ("|                      |\n");
	printf ("|  ѧ��                |\n");
	printf ("|                      |\n");
	printf ("|  enterȷ��   esc���� |\n");
}
void ShowSavedUi()
{
	system("cls");
	printf ("|   ѧ����Ϣ����       |\n");
	printf ("|                      |\n");
	printf ("|         ����         |\n");
	printf ("|                      |\n");
	printf ("|  enterȷ��   esc���� |\n");
}