/***************************************************************************
** File indentifier:
** Brief:
** Current Verion:  v1.0
** Auther: ��tom  qq1005252070
** Complete date: 
** Modify record:
** Modify record:
** Modify date:
** Version:
** Modify content:
***************************************************************************/
#ifndef __STUINFO_H
#define __STUINFO_H
#define MAX_LEN 10
typedef struct studSTINFO
{
	char szNo[MAX_LEN+1];
	char szName[MAX_LEN+1];
	int nAge;
	float fGrade;
	float fTuition;
	int  nRmvFlag;/**< ɾ����־ */
	
}STINFO;
#define STINFO_SIZE sizeof(STINFO)
void PrintStuInfo(void *);
int FindStu (void* pData,char* psValue);
int FindStuByName (void* pData,char* psValue);
int nRmvStu (void* pData,char* psValue);
int nRtnAddStu(void* pData);
#endif //_STUINFO_H_