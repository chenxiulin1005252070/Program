#ifndef _COMMMENTLIST_H__
#define _COMMMENTLIST_H__
typedef struct listSTCOMMENT

#endif//_COMMMENTLIST_H__