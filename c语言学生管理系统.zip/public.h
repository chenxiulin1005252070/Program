/***************************************************************************
** File indentifier:
** Brief:
** Current Verion:  v1.0
** Auther: ��tom  qq1005252070
** Complete date: 
** Modify record:
** Modify record:
** Modify date:
** Version:
** Modify content:
***************************************************************************/
#ifndef __PUBLIC_H
#define __PUBLIC_H
#include <time.h>
#include <stdio.h>
#define APP_SUCC 1
#define APP_FAIL 0
#define APP_BACK -1
#define LEFT_CLICK -2
#define RIGHT_CLICK -3

#define EACH_PAGE_COUNT 3

void GetCurTime(char * pszTime);
void SetCurPos(int nX,int nY);
void ClearSpace(int nX,int nY);/**< ��ղ��ֿհ� */
void PrintTextPos(int nX,int nY,char * psText);
int nChooseFuc(int nX,int nY,int nCount, int nSpace, char *psText, int ,int nTempChoose);
int nChooseFucLr(int nX,int nY,int nCount, int nSpace, char *psText);
/**
* @fn CtrInput
* @brief ������ƺ���
* @param in 
*			char *psIn    ������ַ���
*			int nLength	  �ַ�������
*			int nMode	   ��ʾ��ʽ ��0��Ӣ�� 1�����֣�2����
* @return 
* @li  
*/

int nCtrInput(char *psIn, int nLength, int nMode);/**< ������ */


#endif // _PUBLIC_H__