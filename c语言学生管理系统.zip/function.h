/***************************************************************************
** File indentifier:
** Brief:
** Current Verion:  v1.0
** Auther: ��tom  qq1005252070
** Complete date: 
** Modify record:
** Modify record:
** Modify date:
** Version:
** Modify content:
***************************************************************************/
#ifndef __FUNCTION_H
#define __FUNCTION_H
#include "commonlist.h"
#include "stuInfo.h"
#include <stdio.h>
STCOMLIST * InitFunc(char* psName,FILE** pFile, int (*pFunc)(void *pData));
void ShowDisplayFuc(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse, FILE* pFile);
void SubShowDelFucOne(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile, int nIndex);
void SubShowDelFucAll(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile);
void SubShowDelFuc(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile,int nCurrPage,int nCurrChos);
void ShowDelFuc(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile);
void ShowAddFuc(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile);
void ShowSrchFuc(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile);
int nSubSrchFuc(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile);
void ShowModFuc(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile);
void ShowModSub(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile, int nIndex);
int ShowSrchSub(STINFO* pData, int nIndex);
#endif //__FUNCTION_H