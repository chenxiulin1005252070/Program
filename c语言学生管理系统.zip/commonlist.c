#include "commonlist.h"
#include "public.h"
STCOMLIST *pInitList()
{
	STCOMLIST *stListHead = (STCOMLIST *)malloc (COMMON_LIST_SIZE );
	stListHead -> pNext = NULL;
	return stListHead;
}
void AddList(STCOMLIST* stListHead ,void* pData)
{
	int nTempCount = 0;
	STCOMLIST *pTemp = stListHead;
	STCOMLIST *pNode = (STCOMLIST *)malloc (COMMON_LIST_SIZE );
	while (pTemp->pNext != NULL)
	{
		nTempCount ++;
		pTemp = pTemp->pNext;
	}
	pTemp->pNext = pNode;
	pNode->pData = pData;
	pNode->pNext = NULL;
}
void* pRmvListReal(STCOMLIST* stListHead ,int nIndex)
{
	int nTempCount = 0;
	STCOMLIST *pstListPre;
	STCOMLIST *pstListNext;
	int nListSum = 0;
	pstListPre = pstListNext = stListHead;
	nListSum = nCalListSum(stListHead);
	if (nListSum < nIndex)
		return NULL;
	pstListNext = stListHead->pNext;
	for(; nTempCount < nIndex; nTempCount ++)
	{
		pstListPre = pstListPre->pNext;
		pstListNext = pstListNext->pNext;
	}
	pstListPre->pNext = pstListNext->pNext;
	return pstListNext->pData;


}
int nRmvListFalse(STCOMLIST *stListHead ,int (*pFunc)(void *pData, char *),char *psValue)
{
	STCOMLIST *pstListNext = stListHead;
	while (pstListNext ->pNext != NULL)
	{
		pstListNext = pstListNext ->pNext;
		if (pFunc (pstListNext -> pData, psValue) == APP_SUCC)
			return APP_SUCC;
	}
	return APP_FAIL;

}
int nSrchList(STCOMLIST *stListHead,int (*pnFunc)(void *,char * ),char *pcValue)
{
	int nTempCount = 0;
	STCOMLIST *pTemp = stListHead;
	while (pTemp->pNext != NULL)
	{
		nTempCount ++;
		pTemp = pTemp->pNext;
		if(pnFunc(pTemp->pData,pcValue) != 0)//�Ƿ��ҵ�
		{
			return nTempCount;
		}
	}
	return -1;/*notfound*/
}
int nCalListSum(STCOMLIST *stListHead)
{
	int nTempCount = 0;
	STCOMLIST *pTemp = stListHead;
	while (pTemp->pNext != NULL)
	{
		nTempCount ++;
		pTemp = pTemp->pNext;
	}
	return nTempCount ;

}
void PrintList(STCOMLIST *stListHead,void (*pFunc)(void *),int nCurrPage, int nPageSize,int nX,int nY,int nSpace)
{
	STCOMLIST *pTemp = stListHead;
	int nListSum = 0;
	int nCount = 0;
	int nPrintCount = 0;
	nListSum = nCalListSum(stListHead);
	for(;nCount < nCurrPage * nPageSize; nCount++)
			pTemp = pTemp->pNext;
	for(nCount = 0; nCount < nPageSize && pTemp->pNext != NULL ; nCount ++)
	{
		pTemp = pTemp->pNext;
		SetCurPos(nX,nY +(nPrintCount+1)*nSpace);
		nPrintCount ++;
		pFunc(pTemp->pData);
	}

}
void PrintListAll(STCOMLIST *stListHead,void (*pFunc)(void *))
{
	STCOMLIST *pTemp = stListHead;
	int nListSum = 0;
	int nCount = 0;
	int nPrintCount = 0;
	nListSum = nCalListSum(stListHead);

	while (pTemp->pNext != NULL )
	{	
		
		pTemp = pTemp->pNext;
		nPrintCount ++;
		pFunc(pTemp->pData);
	}
}
void* pFindEndList(STCOMLIST *stListHead)
{
	void *pData = NULL;
	STCOMLIST *pstTemp = stListHead;
	if(pstTemp == NULL|| pstTemp->pNext == NULL)
		return NULL;

	while( pstTemp->pNext != NULL)
	{
		pstTemp = pstTemp->pNext;
	
	}

	return pstTemp->pData;
}

void* pFindListItem(STCOMLIST *stListHead, int nIndex)
{
	int nTempCount = 0;
	STCOMLIST *pstList = NULL;
	int nListSum = 0;
	pstList = stListHead;
	nListSum = nCalListSum(stListHead);
	if(nListSum < nIndex)
		return NULL;
	for(nTempCount = 0; nTempCount <= nIndex; nTempCount++)
		pstList = pstList->pNext;
	return pstList->pData;

}
void* pFindListItemByNo(STCOMLIST *stListHead,int (*pnFunc)(void *,char *), char* pcValue )
{
	STCOMLIST* pstTempList = stListHead;
	while(pstTempList->pNext != NULL)
	{
		pstTempList = pstTempList->pNext;
		if(pnFunc(pstTempList->pData,pcValue))
		{
			return pstTempList->pData;
		}
	}

	return NULL;

}