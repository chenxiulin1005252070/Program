#include "function.h"
#include "public_ui.h"
#include "public.h"
#include "fileope.h"
#include "stuInfo.h"
#include <conio.h>
#include <windows.h>
STCOMLIST * InitFunc(char* psName,FILE** pFile,int (*pFunc)(void *pData))
{
	STCOMLIST* pstStuList;	
	*pFile = pOpenFile(psName);
	pstStuList = pReadFile(*pFile,STINFO_SIZE, pFunc);
	return pstStuList;

}

void ShowDisplayFuc(STCOMLIST* pstStuList,STCOMLIST* pstStuListFalse, FILE* pFile)
{
	int nRtnChoose = 0;
	int nStuSum ;
	int nPageSum;
	int nCurrPage = 1;
	int nCurrSum = 0;
	char szPageSum[5+1] = "";
	char szCurrPage[5+1] = "";
	STINFO* pData = NULL;
	while(1)
	{
		ShowDisplayUi();
		nStuSum = nCalListSum(pstStuList);
		memset(szPageSum, 0, sizeof(szPageSum) );
	    nPageSum = (nStuSum + EACH_PAGE_COUNT -1) / EACH_PAGE_COUNT;
	    sprintf(szPageSum,"%d ҳ",nPageSum);
		nCurrSum = nCurrPage * EACH_PAGE_COUNT  < nStuSum ? EACH_PAGE_COUNT : (nStuSum -nCurrPage * EACH_PAGE_COUNT + EACH_PAGE_COUNT);
		memset(szCurrPage, 0, sizeof(szCurrPage) );
		if(nPageSum == 0)
			nCurrPage = 0;
		sprintf(szCurrPage,"%d /",nCurrPage);
		PrintTextPos(18, 4, szPageSum);
		PrintTextPos(15, 4, szCurrPage);
		if(nCurrSum == 0)
		{	
			while(1)
			{
				SetCurPos(2,3);
				printf("��ǰ�����ݣ���esc����");
				if (getch() != 27)
					;
				else
					return ;
			}
			
		}
		PrintList(pstStuList,PrintStuInfo,nCurrPage-1,EACH_PAGE_COUNT,3,0,1);
		nRtnChoose = nChooseFuc(1,0,nCurrSum,1,"��",1,0);
		switch(nRtnChoose)
		{
		case LEFT_CLICK:
			{
				if(nCurrPage >1)
				nCurrPage --;
				else
				{
					SetCurPos(3,2);
					printf("  �Ѿ��ǵ�һҳ   ");
					Sleep(500);
				}
				break;
			}
		case RIGHT_CLICK:
			{
				if(nCurrPage < nPageSum)
					nCurrPage ++;
				else
				{
					SetCurPos(3,2);
					printf("  �Ѿ������һҳ   ");
					Sleep(500);
				}
				break;
			}
		case  APP_BACK:
			return;
		default :
			/**< �õ���ǰ������ �޸�ɾ�� ����*/
			{
				pData = (STINFO* )pFindListItem(pstStuList, (nCurrPage -1) *EACH_PAGE_COUNT +nRtnChoose);
				ShowSrchSub(pData, (nCurrPage -1) *EACH_PAGE_COUNT +nRtnChoose);	
			}
			break;
		
		}
	
	
	}
}

void SubShowDelFucOne(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse, FILE* pFile, int nIndex)
{
	int nRtnChoose = 0 ;
	STINFO *pstNode = NULL;
	int nPos = 0;/**< �ڼ������е�λ�� */

	ShowDelUiOne(4, 1);
	nRtnChoose = nChooseFucLr(-3,3,2,8,"��");
	switch (nRtnChoose)
	{
	case  APP_BACK:
		return;
	case 0:
		pstNode = (STINFO *)pRmvListReal(pstStuList , nIndex);	/**< ��ɾ�� */
		pstNode->nRmvFlag = 1;
    	nPos = nSrchList(pstStuListFalse, FindStu, pstNode->szNo);
	
		nRmvListFalse(pstStuListFalse , nRmvStu, pstNode->szNo);/**< ��ɾ�� */
    	UpdateFile(pFile,nPos, pstNode, STINFO_SIZE);	/**< �����ļ� */
	    free (pstNode);/**< �ͷ� */
		break;
	case 1:
		break;
	}
}

void ShowAddFuc(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile)
{
	int nRtnChoose = 0;
	int nCurrPage = 1;
	int nCurrSum = 0;
	int nSuccess = 0;
	char szPageSum[5+1] = "";
	char szCurrPage[5+1] = "";
	char szAge[3+1] = "";
	char szGrade[3+2] = "";
	char szTuition[6+2] = "";
	long int lNo = 0;
	int nRtnChs = 0;
	int nRtnFound = 0;
	int nRtnTempChs = 0;
	STINFO*	pstLastNode = NULL;
	STINFO* pstNode = (STINFO *)malloc(STINFO_SIZE);
	STINFO* pstNodeFalse = (STINFO *)malloc(STINFO_SIZE);
	memset(pstNode, 0, STINFO_SIZE);
	memset(pstNodeFalse, 0, STINFO_SIZE);
	while(1)
	{
		ShowAddUi();/**< ��ʾ���� */
		pstLastNode = (STINFO* )pFindEndList(pstStuListFalse);	/**< ѧ���Լ� */
		if(pstLastNode != NULL)
			lNo = atol(pstLastNode->szNo);
		else
			lNo = 1000;
		ClearSpace(8, 1);
		SetCurPos(8, 1);
		printf("%d",lNo +1);
		sprintf(pstNode->szNo, "%d", lNo +1);
		nRtnChoose = nChooseFuc(1,1,6,1,"��",0,0);
		switch(nRtnChoose)
		{
		case 0:
			{
				while(1)
				{
					
					ShowNameUi();
					SetCurPos(8,2);
					printf("         ");
					SetCurPos(8,2);
					
					nSuccess = 0;
					memset(pstNode->szName, 0, MAX_LEN+1);
					nRtnChs = nCtrInput(pstNode->szName,MAX_LEN,2);/**< ���� */
					switch (nRtnChs)
					{
					case APP_SUCC:
						nSuccess = 1;
						break;
					case APP_FAIL:
						SetCurPos(8,2);
						printf("���ֲ�Ϊ��");
						Sleep(400);
						/**< ��յ�ǰ������ */
						break;
					case APP_BACK:
						memset(pstNode->szName, 0, MAX_LEN+1);
						nSuccess = 1;
						break;
					}
					if(nSuccess)
						break;		
				}
				break;
			}
		case 1:
			while(1)
			{		
				nSuccess = 0;
				ShowAgeUi();
				SetCurPos(8,2);
				printf("         ");
				SetCurPos(8,2);
				nRtnChs = nCtrInput(szAge,3,1);
				switch (nRtnChs)
				{
				case APP_SUCC:
					{
						nSuccess = 1;
					}
					break;
				case APP_FAIL:
					SetCurPos(8, 2);
					printf("���䲻Ϊ��");
					Sleep(400);
					/**< ��յ�ǰ������ */
					break;
				case APP_BACK:
					nSuccess = 1;
					break;
				}
				if(nSuccess)
					break;		
			}
			break;
		case 2:
			while(1)
			{
				
				
				nSuccess = 0;
				ShowGradeUi();
				SetCurPos(8,2);
				printf("         ");
				SetCurPos(8,2);
				nRtnChs = nCtrInput(szGrade,3,3);
				switch (nRtnChs)
				{
				case APP_SUCC:
					{
						nSuccess = 1;
					}
					break;
				case APP_FAIL:
					SetCurPos(8,2);
					printf("���㲻Ϊ��");
					Sleep(400);
					/**< ��յ�ǰ������ */
					break;
				case APP_BACK:
					nSuccess = 1;
					break;
				}
				if(nSuccess)
					break;		
			}

			break;
		case 3:
			while(1)
			{
				
				nSuccess = 0;
				ShowTuiTionUi();
				SetCurPos(8,2);
				printf("         ");
				SetCurPos(8,2);
				nRtnChs = nCtrInput(szTuition,6,3);
				switch (nRtnChs)
				{
				case APP_SUCC:
					{
						nSuccess = 1;
					}
					break;
				case APP_FAIL:
					SetCurPos(8,2);
					printf("ѧ�Ѳ�Ϊ��");
					Sleep(400);
					break;
				case APP_BACK:
					nSuccess = 1;
					break;
				}
				if(nSuccess)
					break;		
			}
			break;
		case 4:/**< ���� */
			if(strlen(pstNode->szName) == 0)
			{
				SetCurPos(1,2);
				printf("      ������Ϊ��      ");
				Sleep(500);
				break;
			}
			pstNode->nAge = atoi(szAge);
			pstNode->fGrade = (float)atof(szGrade);
			pstNode->fTuition = (float)atof(szTuition);
			pstNode->nRmvFlag = 0;
			AddList(pstStuList ,pstNode);
			memcpy(pstNodeFalse, pstNode, STINFO_SIZE);
			AddList(pstStuListFalse ,pstNodeFalse);
			AppendFile(pFile,pstNode, STINFO_SIZE);
			return;
		case 5:	
			
		case APP_BACK:
			{
				free ( pstNode);
				return ;
			}
			
		default :
			break;
			
		}
	
	
		
	}
}

void ShowSrchFuc(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile)
{
	
	int nRtnSrch = 0;
	STINFO* pData = NULL;
	while (1)
	{
		ShowSrchUi();
		nRtnSrch = nSubSrchFuc(pstStuList, pstStuListFalse, pFile);
		pData = (STINFO* )pFindListItem(pstStuList, nRtnSrch);
		if(ShowSrchSub(pData, nRtnSrch) < 0)
			break;
	}
	
}
int ShowSrchSub(STINFO* pData, int nIndex)
{
	int nRtnChs = 0;

	
	/**< �ҵ��˲���ʾ */
	if(nIndex >= 0)
	{
		ShowDisplayUi();/**< ��ӡ�����Ľ��� */
		SetCurPos(3, 1);
		printf("                   ");
		SetCurPos(3, 1);
		printf("ѧ�� %s", pData->szNo);
		SetCurPos(3, 2);
		printf("                    ");
		SetCurPos(3, 2);
		printf("���� %s", pData->szName);
		SetCurPos(3, 3);
		printf("                    ");
		SetCurPos(3, 3);
		printf("���� %d", pData->nAge);
		while(1)
		{
			
			nRtnChs = nChooseFuc(3, 1, 2, 0, "", 1, 0);
			switch (nRtnChs)
			{
			case LEFT_CLICK:
				SetCurPos(3, 1);
				printf("                   ");
				SetCurPos(3, 1);
				printf("ѧ�� %s", pData->szNo);
			
				SetCurPos(3, 2);
				printf("                   ");
				SetCurPos(3, 2);
				printf("���� %s", pData->szName);
				SetCurPos(3, 3);
				printf("                   ");
				SetCurPos(3, 3);
				printf("���� %d", pData->nAge);
				break;
			case RIGHT_CLICK:
				SetCurPos(3, 1);
				printf("                   ");
				SetCurPos(3, 1);
				printf("���� %g", pData->fGrade);
				SetCurPos(3, 2);
				printf("                   ");
				SetCurPos(3, 2);
				printf("ѧ�� %g", pData->fTuition);
				SetCurPos(3, 3);
				printf("             ");
				break;
			case APP_BACK:
				return 0;
				break;
			default:
				break;
			}
		
				
		}
		
	}
	else
		return -1;

}
int nSubSrchFuc(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile)
{
	int nRtnChoose = 0;
	int nRtnSrch = 0;
	char szNo[MAX_LEN+1] = "";

	while(1)
	{
		SetCurPos(8,2);
		printf("         ");
		SetCurPos(8,2);
		nRtnChoose = nCtrInput(szNo, MAX_LEN, 1);
		switch (nRtnChoose)
		{
		case APP_SUCC:
			{
				nRtnSrch = nSrchList(pstStuList,FindStu,szNo);/**< �����û� */
				if(nRtnSrch < 0)
				{
					/**< ��ʾû�ҵ� */
					SetCurPos(8,2);
					printf("���޸�ѧ��");
					Sleep(500);
				}
				else
				{
					return nRtnSrch -1;/**< �ҵ� ���ص�ǰ�ڼ���*/
					
				}
			}
			break;
		case APP_FAIL:
			{
				SetCurPos(8,2);
				printf("ѧ�Ų�Ϊ��");
				Sleep(500);
				break;
			}
		case APP_BACK:
			return -1;
		}
	}




}
void SubShowDelFucAll(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile)
{
	int nRtnChoose = 0 ;
	STINFO *pstNode = NULL;
	int nPos = 0;/**< �ڼ������е�λ�� */
	ShowDelUiOne(4, 1);
	nRtnChoose = nChooseFucLr(-3,3,2,8,"��");
	switch (nRtnChoose)
	{
	case  APP_BACK:
		return;
	case 0:
		for( ; nCalListSum(pstStuList);)
		{
			pstNode = (STINFO *)pRmvListReal(pstStuList , 0);	/**< ��ɾ�� */
			pstNode->nRmvFlag = 1;
			nPos = nSrchList(pstStuListFalse, FindStu, pstNode->szNo);
		
			nRmvListFalse(pstStuListFalse , nRmvStu, pstNode->szNo);/**< ��ɾ�� */
			UpdateFile(pFile,nPos, pstNode, STINFO_SIZE);	/**< �����ļ� */
			free (pstNode);/**< �ͷ� */
		}
	
		break;
	case 1:
		break;
	}
}
void ShowDelFuc(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile)
{
	int nRtnChoose = 0;
	int nStuSum ;
	int nPageSum;
	int nCurrPage = 1;
	int nCurrSum = 0;
	char szPageSum[5+1] = "";
	char szCurrPage[5+1] = "";
	
	
	while(1)
	{
		ShowDisplayUi();
		nStuSum = nCalListSum(pstStuList);
		memset(szPageSum, 0, sizeof(szPageSum) );
		nPageSum = (nStuSum + EACH_PAGE_COUNT -1) / EACH_PAGE_COUNT;
		sprintf(szPageSum,"%d ҳ",nPageSum);
		nCurrSum = nCurrPage * EACH_PAGE_COUNT  < nStuSum ? EACH_PAGE_COUNT : (nStuSum -nCurrPage * EACH_PAGE_COUNT + EACH_PAGE_COUNT);
		memset(szCurrPage, 0, sizeof(szCurrPage) );
		if(nPageSum == 0)
			nCurrPage = 0;
		sprintf(szCurrPage,"%d /",nCurrPage);
		PrintTextPos(18, 4, szPageSum);
		PrintTextPos(15, 4, szCurrPage);
		if(nCurrSum == 0)
		{	
			while(1)
			{
				SetCurPos(2,3);
				printf("��ǰ�����ݣ���esc����");
				if (getch() != 27)
					;
				else
					return ;
			}
			
		}
		PrintList(pstStuList,PrintStuInfo,nCurrPage-1,EACH_PAGE_COUNT,3,0,1);
		nRtnChoose = nChooseFuc(1,0,nCurrSum,1,"��",1,0);
		switch(nRtnChoose)
		{
		case LEFT_CLICK:
			{
				if(nCurrPage >1)
					nCurrPage --;
				else
				{
					SetCurPos(3,2);
					printf("  �Ѿ��ǵ�һҳ   ");
					Sleep(500);
				}
				break;
			}
		case RIGHT_CLICK:
			{
				if(nCurrPage < nPageSum)
					nCurrPage ++;
				else
				{
					SetCurPos(3,2);
					printf("  �Ѿ������һҳ   ");
					Sleep(500);
				}
				break;
			}
		case  APP_BACK:
			return;
		default :
			/**< �õ���ǰ������ �޸�ɾ�� ����*/
			{
				
				SubShowDelFuc(pstStuList,  pstStuListFalse, pFile,nCurrPage-1,nRtnChoose);
			}
			break;
			
		}
		
		
	}
}
void SubShowDelFuc(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile,int nCurrPage,int nCurrChos)
{
	int nRtnChoose = 0;
	
	while(1)
	{
		
		ShowDelUi(2, 0);
		nRtnChoose = nChooseFuc(3,0,2,1,"��",0,0);
		switch(nRtnChoose)
		{
		case  APP_BACK:
			return;
		default :
			/**< �õ���ǰ������ ɾ�� ����*/
			{
				switch (nRtnChoose)
				{
				case 0:
						SubShowDelFucAll(pstStuList, pstStuListFalse, pFile);
						return;
					break;
				case 1:
					{
						
						SubShowDelFucOne(pstStuList, pstStuListFalse, pFile, nCurrPage *EACH_PAGE_COUNT +nCurrChos);
						return ;
					}
					break;//ɾ��
				}
			}
			break;
			
		}
	}
}
void ShowModFuc(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile)
{
	int nCurrIndex = 0;/**< ��ǰ���� */ 
	char szNo[MAX_LEN+1] = "";
	char szName[MAX_LEN+1] = "";
	char szAge[3+1] = "";
	char szGrade[3+2] = "";
	char szTuition[6+2] = "";
	int nRtnChs = 0;
	int nRtnSrch = 0;
	int nRtnChoose = 0;
	int nExitLoop = 0;
	int nPos = 0;
	int nExitSubLp = 0;/**< �˳���ѭ�� */
	STINFO* pData = NULL;
	STINFO* pstFalsNde = NULL;
	while(1)
	{
		//ShowModFucUi();
		ShowDisplayUi();
		ShowModSubUi(2, 0);
		//ShowSrchUi();
		ClearSpace(9, 2);
		memset(szNo, 0, MAX_LEN);
		nRtnChs = nCtrInput(szNo, MAX_LEN, 1);
		switch (nRtnChs)
		{
		case APP_SUCC:
			{
				
					nRtnSrch = nSrchList(pstStuList,FindStu,szNo);
					if(nRtnSrch < 0)
					{
						SetCurPos(8,2);
						printf("����������");
						Sleep(500);
					}	
					else
					{
						pData = (STINFO* )pFindListItem(pstStuList, nRtnSrch -1);
						pstFalsNde = (STINFO* )pFindListItemByNo(pstStuListFalse,FindStu,pData->szNo);
					/**< ��ѯ ���Ҹ��� */
						ShowNameUi();
						SetCurPos(8,2);
						printf("%s", pData->szName);
						SetCurPos(8,2);
						while(1)
						{
							nExitLoop = 0;
							nRtnChoose = nChooseFuc(8, 2, 4, 0, "", 1, 0);
							switch(nRtnChoose)
							{
							case  APP_BACK:
								nExitLoop = 1;
								break;
							case LEFT_CLICK:
								nCurrIndex --;
								if (nCurrIndex < 0)
									nCurrIndex = 0;

								break;
							case RIGHT_CLICK:
								nCurrIndex ++;
									if (nCurrIndex > 3)
									nCurrIndex = 3;
								break;
							default:
								switch (nCurrIndex)
								{
								case 0:
									memset(szName, 0, MAX_LEN+1);
									memcpy(szName, pData->szName, MAX_LEN+1);
								
									nRtnChs = nCtrInput(szName, MAX_LEN, 2);
									switch (nRtnChs)
									{
									case APP_SUCC:
										memset(pData->szName, 0, MAX_LEN +1);
										memcpy(pData->szName, szName, MAX_LEN +1);
										memcpy(pstFalsNde->szName, szName, MAX_LEN +1);
										/**< ���ҽڵ㣬���Ҹ����ļ� */
										nPos = nSrchList(pstStuListFalse,FindStu, pData->szNo);
										//�����ļ�
										UpdateFile(pFile, nPos, pstFalsNde, STINFO_SIZE);
										break;
									case APP_FAIL:
										SetCurPos(8,2);
										printf("������Ϊ��");
										Sleep(400);
										/**< ��յ�ǰ������ */
										break;
									case APP_BACK:
										break;
									}						
									break;
								case 1:
									memset(szAge, 0, 3);
									sprintf(szAge,"%d",pData->nAge);	
									nRtnChs = nCtrInput(szAge, 3, 1);
									switch (nRtnChs)
									{
									case APP_SUCC:
										pData->nAge = atoi(szAge);
										pstFalsNde->nAge = pData->nAge;
										/**< ���ҽڵ㣬���Ҹ����ļ� */
										nPos = nSrchList(pstStuListFalse,FindStu, pData->szNo);
										//�����ļ�
										UpdateFile(pFile, nPos, pstFalsNde, STINFO_SIZE);
										break;
									case APP_FAIL:
										SetCurPos(8,2);
										printf("���䲻Ϊ��");
										Sleep(400);
										/**< ��յ�ǰ������ */
										break;
									case APP_BACK:
										break;
								
									}
									break;
								case 2:
								
									memset(szGrade, 0, 5);
									sprintf(szGrade,"%g",pData->fGrade);
									nRtnChs = nCtrInput(szGrade, 3, 3);;
									switch (nRtnChs)
									{
									case APP_SUCC:
										pData->fGrade = (float)atof(szGrade);
										pstFalsNde->fGrade = pData->fGrade;
										/**< ���ҽڵ㣬���Ҹ����ļ� */
										nPos = nSrchList(pstStuListFalse,FindStu, pData->szNo);
										//�����ļ�
										UpdateFile(pFile, nPos, pstFalsNde, STINFO_SIZE);
										break;
									case APP_FAIL:
										SetCurPos(8,2);
										printf("���㲻Ϊ��");
										Sleep(400);
										/**< ��յ�ǰ������ */
										break;
									case APP_BACK:
										break;
									}
								
									break;
								case 3:
									
									
									memset(szTuition, 0, 8);
									sprintf(szTuition,"%g",pData->fTuition);
									nRtnChs = nCtrInput(szTuition, 6, 3);
									switch (nRtnChs)
									{
									case APP_SUCC:
										pData->fTuition = (float)atof(szTuition);
										pstFalsNde->fTuition = pData->fTuition;
										/**< ���ҽڵ㣬���Ҹ����ļ� */
										nPos = nSrchList(pstStuListFalse,FindStu, pData->szNo);
										//�����ļ�
										UpdateFile(pFile, nPos, pstFalsNde, STINFO_SIZE);
										break;
									case APP_FAIL:
										SetCurPos(8,2);
										printf("ѧ�Ѳ�Ϊ��");
										Sleep(400);
										/**< ��յ�ǰ������ */
										break;
									case APP_BACK:
										
										break;
									}
										
									break;
							
								break;
								}
							}
							switch (nCurrIndex)
							{
							case 0:
								ShowNameUi();
								memset(szName, 0, MAX_LEN);
								memcpy(szName, pData->szName, MAX_LEN);
								SetCurPos(8,2);
								printf("%s", pData->szName);
								
								break;
							case 1:
								ShowAgeUi();
								SetCurPos(8,2);
								printf("%d", pData->nAge);
								
								break;
							case 2:
								ShowGradeUi();
								SetCurPos(8,2);
								printf("%g", pData->fGrade);
								break;
							case 3:
								ShowTuiTionUi();
								SetCurPos(8,2);
								printf("%g", pData->fTuition);
								break;
						
							}
							if(nExitLoop)
								break;
							
							SetCurPos(8,2);	
						}
					}
							
			}
			break;
		case APP_FAIL:
			{
				SetCurPos(8,2);
				printf("ѧ�Ų�Ϊ��");
				Sleep(500);
				break;
			}
		case APP_BACK:
			return ;
		}

	}

}
void ShowModSub(STCOMLIST* pstStuList, STCOMLIST* pstStuListFalse,FILE* pFile, int nIndex)
{
	

	STINFO *pstTmpNde = NULL;
	STINFO *pstFalsNde = NULL;
	char szName[MAX_LEN+1] = "";
	char szAge[3+1] = "";
	char szGrade[3+2] = "";
	char szTuition[6+2] = "";
	int nRtnChoose = 0;
	int nSuccess = 0;
	int nRtnChs = 0;
	int nPos = 0;/**< ��false�����еڼ���Ԫ�� */
	/**< ��д */
	ShowModFucUi();
	
	pstTmpNde = pFindListItem(pstStuList,  nIndex);

	SetCurPos(18,3);
	printf("%s",pstTmpNde->szNo);
	SetCurPos(18,5);
	printf("%s",pstTmpNde->szName);
	SetCurPos(18,7);
	printf("%d",pstTmpNde->nAge);
	SetCurPos(18,9);
	printf("%.2f",pstTmpNde->fGrade);
	SetCurPos(18,11);
	printf("%.2f",pstTmpNde->fTuition);
	nRtnChoose = nChooseFuc(5,3,4, 2, "��", 0,0);
	switch(nRtnChoose)
	{
	case  APP_BACK:
		return;
	default :
		/**< �õ���ǰ������ �޸�ɾ�� ����*/
		{
			switch (nRtnChoose)
			{
			case 0:					
					while(1)
					{
						nSuccess = 0;
						ClearSpace(18,5);
						memset(szName, 0, MAX_LEN+1);
						nRtnChs = nCtrInput(szName,MAX_LEN,2);/**< ���� */
						switch (nRtnChs)
						{
						case APP_SUCC:
							nSuccess = 1;
							break;
						case APP_FAIL:
							SetCurPos(18,5);
							printf("���ֲ�Ϊ��");
							Sleep(400);
							/**< ��յ�ǰ������ */
						break;
						case APP_BACK:
						
						return;
							break;
						}
						if(nSuccess)
							break;		
					}
				
					/**< ����ѡ���Ƿ񱣴� */
					nRtnChoose = nChooseFucLr(1, 14,2, 15, "��");
					switch (nRtnChoose)
					{
					case  APP_BACK:
						return;
					case 0:
						memset(pstTmpNde->szName, 0, MAX_LEN+1);
						memcpy(pstTmpNde->szName, szName,MAX_LEN+1);
						pstFalsNde = (STINFO* )pFindListItemByNo(pstStuListFalse,FindStu,pstTmpNde->szNo);
						memset(pstFalsNde->szName, 0, MAX_LEN + 1);
						memcpy(pstFalsNde->szName, pstTmpNde->szName, MAX_LEN + 1);
						/**< ���ҽڵ㣬���Ҹ����ļ� */
						nPos = nSrchList(pstStuListFalse,FindStu, pstTmpNde->szNo);
						//�����ļ�
						UpdateFile(pFile, nPos, pstFalsNde, STINFO_SIZE);
						break;
					case 1:
						break;
					}
					
				break;
			case 1:
				while(1)
				{
					nSuccess = 0;
					ClearSpace(18,7);
					memset(szAge, 0, 3+1);
					nRtnChs = nCtrInput(szAge,3,1);/**< ���� */
					switch (nRtnChs)
					{
					case APP_SUCC:
						nSuccess = 1;
						break;
					case APP_FAIL:
						SetCurPos(18,7);
						printf("���䲻Ϊ��");
						Sleep(400);
						/**< ��յ�ǰ������ */
						break;
					case APP_BACK:
						
						return;
						break;
					}
					if(nSuccess)
						break;		
				}
				/**< �޸ĳɹ��󱣴浽�����ﲢ�޸��ļ� */
				
			
				nRtnChoose = nChooseFucLr(1, 14,2, 15, "��");
				switch (nRtnChoose)
				{
				case  APP_BACK:
					return;
				case 0:
					pstFalsNde = (STINFO* )pFindListItemByNo(pstStuListFalse,FindStu,pstTmpNde->szNo);
					pstTmpNde->nAge = pstFalsNde->nAge = atoi(szAge);
					/**< ���ҽڵ㣬���Ҹ����ļ� */
					nPos = nSrchList(pstStuListFalse,FindStu, pstTmpNde->szNo);
					//�����ļ�
					UpdateFile(pFile, nPos, pstFalsNde, STINFO_SIZE);
					break;
				case 1:
					break;
					}
				break;
			case 2:
				while(1)
				{
					nSuccess = 0;
					ClearSpace(18,9);
					memset(szGrade, 0, 3+2);
					nRtnChs = nCtrInput(szGrade,3,3);/**< ���� */
					switch (nRtnChs)
					{
					case APP_SUCC:
						nSuccess = 1;
						break;
					case APP_FAIL:
						SetCurPos(18,9);
						printf("���㲻Ϊ��");
						Sleep(400);
						/**< ��յ�ǰ������ */
						break;
					case APP_BACK:
						
						return;
						break;
					}
					if(nSuccess)
						break;		
				}
				/**< �޸ĳɹ��󱣴浽�����ﲢ�޸��ļ� */
		
				nRtnChoose = nChooseFucLr(1, 14,2, 15, "��");
				switch (nRtnChoose)
				{
				case  APP_BACK:
					return;
				case 0:
					pstFalsNde = (STINFO* )pFindListItemByNo(pstStuListFalse,FindStu,pstTmpNde->szNo);
					pstTmpNde->fGrade = pstFalsNde->fGrade = (float)atof(szGrade);
					/**< ���ҽڵ㣬���Ҹ����ļ� */
					nPos = nSrchList(pstStuListFalse,FindStu, pstTmpNde->szNo);
					//�����ļ�
					UpdateFile(pFile, nPos, pstFalsNde, STINFO_SIZE);
					break;
				case 1:
					break;
					}
				break;
			case 3:
				while(1)
				{
					nSuccess = 0;
					ClearSpace(18,11);
					memset(szTuition, 0, 6+2);
					nRtnChs = nCtrInput(szTuition,6,3);
					switch (nRtnChs)
					{
					case APP_SUCC:
						nSuccess = 1;
						break;
					case APP_FAIL:
						SetCurPos(18,11);
						printf("ѧ�Ѳ�Ϊ��");
						Sleep(400);
						/**< ��յ�ǰ������ */
						break;
					case APP_BACK:
						
						return;
						break;
					}
					if(nSuccess)
						break;		
				}
				/**< �޸ĳɹ��󱣴浽�����ﲢ�޸��ļ� */
				nRtnChoose = nChooseFucLr(1, 14,2, 15, "��");
				switch (nRtnChoose)
				{
				case  APP_BACK:
					return;
				case 0:
					pstFalsNde = (STINFO* )pFindListItemByNo(pstStuListFalse,FindStu,pstTmpNde->szNo);
					pstTmpNde->fTuition = pstFalsNde->fTuition = (float)atof(szTuition);
				
					/**< ���ҽڵ㣬���Ҹ����ļ� */
					nPos = nSrchList(pstStuListFalse,FindStu, pstTmpNde->szNo);
					//�����ļ�
					UpdateFile(pFile, nPos, pstFalsNde, STINFO_SIZE);
					break;
				case 1:
					break;
					}
				break;

			}	
			
		}
		break;
		
		}
}