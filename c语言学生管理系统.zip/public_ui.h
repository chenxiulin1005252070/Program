/***************************************************************************
** File indentifier:
** Brief:
** Current Verion:  v1.0
** Auther: ��tom  qq1005252070
** Complete date: 
** Modify record:
** Modify record:
** Modify date:
** Version:
** Modify content:
***************************************************************************/
#ifndef __PUBLIC_UI_H
#define __PUBLIC_UI_H
#include <stdio.h>
/**
* @fn showLoginUi
* @brief ��½����Ui
* @param in ��
* @return 
* @li APP_SUCC ��
*/
void ShowLoginUi();
void ShowDisplayUi();
void ShowDelUi(int nX, int nY);
void ShowDelUiOne(int nX, int nY);
void ShowAddUi();
void ShowSrchUi();
void ShowModFucUi();
void ShowModSubUi(int nX, int nY);
void ShowNameUi();
void ShowAgeUi();
void ShowGradeUi();
void ShowTuiTionUi();
void ShowSavedUi();
#endif //_PUBLIC_UI_H__