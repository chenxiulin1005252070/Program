#include "public.h"
#include <windows.h>
#include <conio.h>
void GetCurTime(char * pszTime)
{
     time_t rawtime = 0;
     struct tm * timeinfo = NULL ;
	 time ( &rawtime );
	 timeinfo = localtime (&rawtime );/**��ȡ��ǰʱ�� */
	
	 if(pszTime == NULL)
	 {
		 return;
	 }
	
	 memset (pszTime,0,20);
	 sprintf (pszTime,"%d-%02d-%02d %02d:%02d:%02d",timeinfo->tm_year + 1900,timeinfo->tm_mon+1,timeinfo->tm_mday+1,timeinfo->tm_hour,timeinfo->tm_min,timeinfo->tm_sec);
	
}
void SetCurPos(int nX,int nY)
{
	COORD coCurrPos; 
	coCurrPos.X = nX ; 
	coCurrPos.Y = nY ; 
	SetConsoleCursorPosition (GetStdHandle(STD_OUTPUT_HANDLE), coCurrPos); 

}
void PrintTextPos(int nX,int nY,char * psText)
{
	 SetCurPos( nX,nY);
	 printf("%s",psText);
}
int nChooseFuc(int nX,int nY,int nCount,int nSpace,char *psText,int nChgPgeFlg,int nTempChoose)
{
	//int nTempChoose = 0;//��ʱ
	int cTempCount = 0;
	
	while(1)
	{
	
		if(nTempChoose < 3)
			SetCurPos(nX,nY +(nTempChoose+1)*nSpace);
		else
		{
			SetCurPos(nX + 11,nY +(nTempChoose+1 -3)*nSpace);
		}
		
		printf("%s",psText);
		cTempCount = getch();
		if (cTempCount == 224 )
		{
			cTempCount = getch();
			if(cTempCount == 72)
			{
			   printf("\b\b  \b");
			   if(nCount != 0) 
				nTempChoose --;
				if(nTempChoose < 0 )
					nTempChoose = nCount -1;
			}
			else if (cTempCount == 80)
			{
				printf("\b\b  \b");
				nTempChoose ++;
			
				if(nTempChoose >= nCount)
					nTempChoose = 0;
		
			}
			else if(nChgPgeFlg)
			{
				if(cTempCount == 75)
				{
					return LEFT_CLICK;

				}
				else if(cTempCount == 77)
				{
					return RIGHT_CLICK;
				}	
			}
			
		}
		else if(cTempCount == 13)
		{
			return nTempChoose;
		}
		else if(cTempCount == 27)
		{
			return APP_BACK;
		}
		else if(cTempCount >'0' && cTempCount <= nCount + '0')
		{

			return cTempCount - '1';
		}
	}
}

int nChooseFucLr(int nX,int nY,int nCount, int nSpace, char *psText)
{
	int nTempChoose = 0;//��ʱ
	int cTempCount = 0;
	
	while(1)
	{
	
		SetCurPos(nX + (nTempChoose + 1) * nSpace, nY);
		
		printf("%s",psText);
		cTempCount = getch();
		if (cTempCount == 224 )
		{
			cTempCount = getch();
			if(cTempCount == 75)
			{
			   printf("\b \b");
			   if(nCount != 0) 
				nTempChoose --;
				if(nTempChoose < 0 )
					nTempChoose = nCount -1;
			}
			else if (cTempCount == 77)
			{
				printf("\b \b");
				nTempChoose ++;
			
				if(nTempChoose >= nCount)
					nTempChoose = 0;
		
			}
			
		}
		else if(cTempCount == 13)
		{
			return nTempChoose;
		}
		else if(cTempCount == 27)
		{
			return APP_BACK;
		}
	}
	
}
int nCtrInput(char *psIn, int nLength, int nMode)/**< ������ */
{
	char cTemp = '\0';
	int nTempLength = nLength;
	int nCount = 0;
	if(psIn == NULL)
		return APP_FAIL;
	
	printf("%s", psIn);
	nCount = strlen(psIn);
//	memset (psIn, 0, nLength + 1);
	while(1)
	{
		cTemp = getch ();
		if (cTemp == 8) // ɾ����
		{	
			if (nMode == 2 && nCount) //ָ��Ϊ���Ļ���Ӣ��
			{
				psIn[-- nCount ] = '\0';
				printf("\b \b");
				psIn[-- nCount ] = '\0';
				printf("\b \b");
			}
			else if (nCount)
			{
				psIn[-- nCount ] = '\0';
				printf("\b \b");
				if(nMode == 3)
				{
					if(strchr(psIn,'.') == NULL)
					{
						nLength = nTempLength;
					}
				}

			}
			else
			{
				printf("\a");
			}
		}
		else if (cTemp == 13)
		{
			if(strlen(psIn) > 0)
				return APP_SUCC;
			return APP_FAIL;

		}
		else if (cTemp == 27)
			return APP_BACK;
		else
		{
			if (strlen(psIn) < (unsigned )nLength)
			{
				if (nMode == 0)/**< 0��Ӣ�� 1�����֣�2���� 3. ������*/
				{
					if((cTemp >= 'A' && cTemp <= 'Z' )||(cTemp >= 'a' && cTemp <= 'z') )
					{
						psIn [nCount ++] = cTemp;
						putchar(cTemp);
					}
					else
						putchar('\a');
				}
				else if(nMode == 1)
				{
					if((cTemp >= '0' && cTemp <= '9' ) )
					{
						psIn [nCount ++] = cTemp;
						putchar(cTemp);
					}
					else
						putchar('\a');
						
				}
				else if(nMode == 2)
				{
					//���¼� -32
					if(((unsigned char )cTemp >= 0xA1 && (unsigned char )cTemp <= 0xFE ) && cTemp != -32)
					{
					
						psIn [nCount ++] = cTemp;
						printf("%c",cTemp);
						cTemp = getch ();
						psIn [nCount ++] = cTemp;
						printf("%c",cTemp);
					}	
			    	else
					     putchar('\a');
					 
					
				}
				else if(nMode == 3)
				{
					if((cTemp >= '0' && cTemp <= '9' ) )
					{
						psIn [nCount ++] = cTemp;
						putchar(cTemp);
					}
					else if(cTemp == '.')
					{
						
						if( strchr(psIn,'.') == NULL && strlen(psIn))
						{
							psIn [nCount ++] = cTemp;
							nLength ++;//�����Լ�
							putchar(cTemp);
						}	
						else
						putchar('\a');
					}
					else
						putchar('\a');
					
				}

				
			}
			else
			{
				printf("\a");
			}
		
			
		}
		

	}
	
}
void ClearSpace(int nX,int nY)
{
	SetCurPos(nX,nY);
	printf("           ");
	SetCurPos(nX,nY);	
}
