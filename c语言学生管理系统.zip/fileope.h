/***************************************************************************
** File indentifier:
** Brief:
** Current Verion:  v1.0
** Auther: ��tom  qq1005252070
** Complete date: 
** Modify record:
** Modify record:
** Modify date:
** Version:
** Modify content:
***************************************************************************/
#ifndef __FILEOPE_H
#define __FILEOPE_H
#include <stdio.h>
#include "commonlist.h"
FILE* pOpenFile(char* psName);
void WriteDataFile(FILE* pFile, STCOMLIST *stListHead, int nDataSize);
STCOMLIST* pReadFile(FILE* pFile,int nDataSize, int (*pFunc)(void *pData));
/**
* @fn UpdateFile
* @brief �����ļ�
* @param in 
*			FILE* pFile   �ļ�ָ��
*			int nIndex	  �ڼ���
*			void* pData   ����
*			int nSize     ���ݵĴ�С
* @return 
* @li  ��
*/
void UpdateFile(FILE* pFile,int nIndex, void* pData, int nSize);
void AppendFile(FILE* pFile,void* pData, int nSize);
#endif //_FILEOPE_H_