/***************************************************************************
** File indentifier:
** Brief:
** Current Verion:  v1.0
** Auther: ��tom  qq1005252070
** Complete date: 
** Modify record:
** Modify record:
** Modify date:
** Version:
** Modify content:
***************************************************************************/
#ifndef __COMMONLIST_H
#define __COMMONLIST_H
#include <stdlib.h>
typedef struct listSTCOMLIST
{
	void *pData;
	struct listSTCOMLIST *pNext;
	
}STCOMLIST;

#define COMMON_LIST_SIZE sizeof(STCOMLIST) /**< ͨ����������*/


STCOMLIST *pInitList();
STCOMLIST *pInitListReal();
void AddList(STCOMLIST *stListHead ,void *pData);
void* pRmvListReal(STCOMLIST *stListHead ,int nIndex);
int nRmvListFalse(STCOMLIST *stListHead ,int (*pFunc)(void *pData, char *),char *psValue);
/**
* @fn nSrchList
* @brief ����Ԫ��
* @param in STCOMLIST *stListHead ͨ������ͷ��
			bool (*pnFunc)(void *,int ) ָ���ص�����
			int nValue �ص���������
* @return 
* @li >0 ���صڼ���Ԫ��
*     <0  δ�ҵ�
*/
int nSrchList(STCOMLIST *stListHead,int (*pnFunc)(void *,char *),char *pcValue);
int nCalListSum(STCOMLIST *stListHead);
void PrintList(STCOMLIST *stListHead,void (*pFunc)(void *),int nCurrPage, int nPageSize,int nX,int nY,int nSpace);
void PrintListAll(STCOMLIST *stListHead,void (*pFunc)(void *));
void* pFindEndList(STCOMLIST *stListHead);
void* pFindListItem(STCOMLIST *stListHead, int nIndex);
void* pFindListItemByNo(STCOMLIST *stListHead,int (*pnFunc)(void *,char *), char* pcValue );
#endif/ _COMMONLIST_H_ 