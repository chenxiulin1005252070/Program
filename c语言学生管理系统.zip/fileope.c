#include "fileope.h"
#include <string.h>
FILE* pOpenFile(char* psName)
{
	FILE* pFile = NULL;
	if (psName == NULL)
		return NULL;
	pFile = fopen (psName ,"rb+");
	if (pFile == NULL)
	{
		pFile = fopen (psName ,"wb+");
	}
	return pFile;

}
void WriteDataFile(FILE* pFile, STCOMLIST* stListHead, int nDataSize)
{
	STCOMLIST* pTemp = stListHead;
	if (pFile == NULL)
		return ;
	rewind(pFile);/**< ��ͷд */
	while (pTemp ->pNext != NULL)
	{
		pTemp = pTemp ->pNext;
		fwrite(pTemp ->pData ,nDataSize,1,pFile);
		fflush(pFile);/**< �����ļ� */
	}

}

STCOMLIST* pReadFile(FILE* pFile,int nDataSize, int (*pFunc)(void *pData))
{
	STCOMLIST *pstListHead;
	void *pData = NULL;
	if(pFile == NULL)
		return NULL;
	rewind(pFile);
	pstListHead = pInitList();
	pData = malloc( nDataSize );
	memset (pData, 0, nDataSize);
	while(fread(pData, nDataSize ,1, pFile))
	{
		if(pFunc != NULL)
			if(pFunc(pData))/**< ��ɾ�� */
				continue;
		AddList(pstListHead ,pData);
		pData = malloc(nDataSize );
		memset (pData, 0, nDataSize);
	
	}
	return pstListHead;


}

void UpdateFile(FILE* pFile,int nIndex, void* pData, int nSize)
{
	if (pFile == NULL)
		return ;
	rewind(pFile);
	fseek(pFile, (nIndex - 1) * nSize, SEEK_SET);
	fwrite(pData ,nSize,1,pFile);
	fflush(pFile);/**< �����ļ� */
}
void AppendFile(FILE* pFile,void* pData, int nSize)
{
	fseek(pFile,0, SEEK_END);/**<�ƶ����ļ�����U  */
	fwrite(pData ,nSize,1,pFile);
	fflush(pFile);/**< �����ļ� */
}